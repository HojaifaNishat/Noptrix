
import { model, Schema, type InferSchemaType } from "mongoose";

export const BRAND_STATUSES = ["ACTIVE", "INACTIVE"] as const;
export type BrandStatus = (typeof BRAND_STATUSES)[number];

const brandSchema = new Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
      minlength: 2,
      maxlength: 120,
    },
    slug: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      maxlength: 160,
    },
    description: {
      type: String,
      trim: true,
      maxlength: 3000,
      default: "",
    },
    logo: {
      type: String,
      trim: true,
      maxlength: 2048,
      default: "",
    },
    website: {
      type: String,
      trim: true,
      maxlength: 2048,
      default: "",
    },
    status: {
      type: String,
      enum: BRAND_STATUSES,
      default: "ACTIVE",
      required: true,
    },
    sortOrder: {
      type: Number,
      min: 0,
      max: 1_000_000,
      default: 0,
    },
    seo: {
      title: { type: String, trim: true, maxlength: 160, default: "" },
      description: { type: String, trim: true, maxlength: 320, default: "" },
    },
    createdBy: {
      type: Schema.Types.ObjectId,
      default: null,
      index: true,
    },
    updatedBy: {
      type: Schema.Types.ObjectId,
      default: null,
    },
  },
  {
    timestamps: true,
    strict: "throw",
    versionKey: false,
    minimize: false,
  },
);

brandSchema.index({ slug: 1 }, { unique: true });
brandSchema.index({ name: 1 }, { unique: true });
brandSchema.index({ status: 1, sortOrder: 1, name: 1 });
brandSchema.index({ createdAt: -1 });
brandSchema.index({ name: "text", description: "text" });

export type IBrand = InferSchemaType<typeof brandSchema>;

export const Brand = model("Brand", brandSchema);
